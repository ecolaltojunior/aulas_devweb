---
title: Cloud moon
categories:
  - Weather
tags:
  - cloudy
  - overcast
---
