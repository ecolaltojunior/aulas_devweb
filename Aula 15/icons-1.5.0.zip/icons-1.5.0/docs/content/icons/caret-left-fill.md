---
title: Caret left fill
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
